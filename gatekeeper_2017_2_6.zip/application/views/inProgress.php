<?php
/**
 * Created by PhpStorm.
 * User: Mohammad Yazdani
 * Date: 2/5/2017
 * Time: 4:22 PM
 */

defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
    <!-- TODO : INCLUDE BOOTSTRAP AND JQUERY JS, AND BOOTSTRAP CSS -->
    <script src="assets/twbs/bootstrap/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="assets/twbs/bootstrap/dist/css/bootstrap.min.css">
    <script src="assets/components/jquery/jquery.min.js"></script>
    <meta charset="utf-8">
    <title>GateKeeper</title>
</head>
<body>
<div class="container-fluid">
    <h1>"Coming soon!"</h1>
</div>
</body>
</html>